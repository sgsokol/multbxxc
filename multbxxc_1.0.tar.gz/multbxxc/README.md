# multbxxc
This is a collection of helper routines written in C++ for software [influx](https://metasys.insa-toulouse.fr/software/influx/). This packages is not intended to be used directly.
