library(testthat)
library(multbxxc)
test_check("multbxxc")
